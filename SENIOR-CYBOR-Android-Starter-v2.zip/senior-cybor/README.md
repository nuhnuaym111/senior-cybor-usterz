# SENIOR CYBOR — DIGITAL USTERZ

Offline-first Android cybersecurity learning app starter.

## Included
- Dark blue and gold mobile interface
- User profile stored locally on the device
- Five cybersecurity learning levels
- Starter lessons and offline quiz
- Basic offline study assistant (prewritten answers, not generative AI)
- Local-device admin prototype
- Capacitor Android configuration
- GitHub Actions workflow to build a debug APK

## Build on GitHub
1. Create a GitHub repository named `senior-cybor`.
2. Upload the contents of this folder to the repository root (including the hidden `.github` folder).
3. Open **Actions** and select **Build SENIOR CYBOR Android APK**.
4. Select **Run workflow**.
5. When complete, open the workflow run and download the `SENIOR-CYBOR-debug-apk` artifact.

## Important prototype limitations
- Profile and progress are stored in browser/app local storage on this device.
- The admin code in this starter is a demonstration only and must be replaced before any real deployment.
- The assistant is an offline FAQ-style helper, not a live AI model.
- PDF and video sections are placeholders until learning files are supplied.
- Local accounts do not synchronize between devices.
- This is a debug APK starter, not a signed Play Store release.

## Local development
Run `npm install`, `npx cap add android`, and `npx cap sync android`. Open the Android project in Android Studio to build or sign a release.
